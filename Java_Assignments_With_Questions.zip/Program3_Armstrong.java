/*
3. Display all armstrong numbers between 100 to 1000 using classes and methods.
*/

class Armstrong {
    boolean isArmstrong(int num) {
        int sum = 0, temp = num;
        while (num > 0) {
            int d = num % 10;
            sum += d * d * d;
            num /= 10;
        }
        return sum == temp;
    }

    void printArmstrongNumbers() {
        for (int i = 100; i <= 1000; i++) {
            if (isArmstrong(i)) System.out.println(i);
        }
    }
}

public class Program3_Armstrong {
    public static void main(String[] args) {
        Armstrong a = new Armstrong();
        a.printArmstrongNumbers();
    }
}