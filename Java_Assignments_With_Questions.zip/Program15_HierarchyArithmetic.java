/*
15. Java program for assignment question 15.
*/
class Numbers {
    int a = 10, b = 5;
}

class Add extends Numbers {
    void compute() {
        System.out.println("Addition: " + (a + b));
    }
}

class Sub extends Numbers {
    void compute() {
        System.out.println("Subtraction: " + (a - b));
    }
}

class Mul extends Numbers {
    void compute() {
        System.out.println("Multiplication: " + (a * b));
    }
}

public class Program15_HierarchyArithmetic {
    public static void main(String[] args) {
        new Add().compute();
        new Sub().compute();
        new Mul().compute();
    }
}