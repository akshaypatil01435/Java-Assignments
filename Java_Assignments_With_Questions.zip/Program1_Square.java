/*
1. Define a class called square with one attribute. 
Write separate methods to calculate area and perimeter of square. 
Call these methods from main() by creating object.
*/

class Square {
    int side;

    int area() {
        return side * side;
    }

    int perimeter() {
        return 4 * side;
    }
}

public class Program1_Square {
    public static void main(String[] args) {
        Square s = new Square();
        s.side = 5;
        System.out.println("Area of Square: " + s.area());
        System.out.println("Perimeter of Square: " + s.perimeter());
    }
}