/*
6. Java program for assignment question 6.
*/
class Shape {
    void area(float radius) {
        System.out.println("Area of Circle: " + (3.14 * radius * radius));
    }

    void area(float base, float height) {
        System.out.println("Area of Triangle: " + (0.5 * base * height));
    }
}

public class Program6_Shape {
    public static void main(String[] args) {
        Shape s = new Shape();
        s.area(5);           // circle
        s.area(4, 6);        // triangle
    }
}