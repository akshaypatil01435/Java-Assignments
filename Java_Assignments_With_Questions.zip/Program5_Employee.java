/*
5. Java program for assignment question 5.
*/
class Employee {
    String name;
    double salary;

    void accept(String n, double s) {
        name = n;
        salary = s;
    }

    void display() {
        System.out.println("Name: " + name);
        System.out.println("Salary: " + salary);
    }
}

public class Program5_Employee {
    public static void main(String[] args) {
        Employee emp = new Employee();
        emp.accept("Alice", 45000);
        emp.display();
    }
}