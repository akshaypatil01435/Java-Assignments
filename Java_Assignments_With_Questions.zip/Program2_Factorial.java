/*
2. Define a class called factorial with one integer attribute. 
Write a method to calculate factorial and call it from main.
*/

class Factorial {
    int n;

    int findFactorial() {
        int fact = 1;
        for (int i = 1; i <= n; i++) {
            fact *= i;
        }
        return fact;
    }
}

public class Program2_Factorial {
    public static void main(String[] args) {
        Factorial f = new Factorial();
        f.n = 5;
        System.out.println("Factorial of " + f.n + " is " + f.findFactorial());
    }
}