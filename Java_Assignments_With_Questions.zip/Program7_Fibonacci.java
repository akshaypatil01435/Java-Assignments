/*
7. Java program for assignment question 7.
*/
class Fibonacci {
    Fibonacci(int n) {
        int a = 0, b = 1;
        int sum = a + b;
        System.out.print(a + " " + b + " ");
        for (int i = 3; i <= n; i++) {
            int c = a + b;
            sum += c;
            System.out.print(c + " ");
            a = b;
            b = c;
        }
        System.out.println("\nSum: " + sum);
    }
}

public class Program7_Fibonacci {
    public static void main(String[] args) {
        Fibonacci f = new Fibonacci(7);
    }
}