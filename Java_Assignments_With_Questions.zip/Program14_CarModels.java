/*
14. Java program for assignment question 14.
*/
class Car {
    String name;
    int price;

    Car(String name, int price) {
        this.name = name;
        this.price = price;
    }

    void display() {
        System.out.println("Car: " + name + ", Price: " + price);
    }
}

public class Program14_CarModels {
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        for (int i = 1; i <= n; i++) {
            Car c = new Car("Car" + i, i * 10000);
            c.display();
        }
    }
}