/*
10. Java program for assignment question 10.
*/
class Student {
    String name;
    int strength;

    Student(String name, int strength) {
        this.name = name;
        this.strength = strength;
    }

    void display() {
        System.out.println("Name: " + name);
        System.out.println("Total Strength: " + strength);
    }
}

public class Program10_StudentCommandLine {
    public static void main(String[] args) {
        Student s = new Student(args[0], Integer.parseInt(args[1]));
        s.display();
    }
}