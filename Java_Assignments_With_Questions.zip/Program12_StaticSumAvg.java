/*
12. Java program for assignment question 12.
*/
class Calc {
    static void compute(int a, int b, int c) {
        int sum = a + b + c;
        float avg = sum / 3.0f;
        System.out.println("Sum: " + sum + ", Average: " + avg);
    }
}

public class Program12_StaticSumAvg {
    public static void main(String[] args) {
        Calc.compute(10, 20, 30);
    }
}