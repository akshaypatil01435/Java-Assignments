/*
16. Java program for assignment question 16.
*/
class Candidate {
    int id;
    String name;
    String qualification;
    int experience;

    Candidate(int id, String name, String qualification, int experience) {
        this.id = id;
        this.name = name;
        this.qualification = qualification;
        this.experience = experience;
    }

    void display() {
        System.out.println(id + " " + name + " " + qualification + " " + experience + "yrs");
    }
}

public class Program16_CandidateList {
    public static void main(String[] args) {
        Candidate[] list = new Candidate[100];
        for (int i = 0; i < 100; i++) {
            list[i] = new Candidate(i + 1, "Name" + (i + 1), "B.Tech", i % 10);
            list[i].display();
        }
    }
}