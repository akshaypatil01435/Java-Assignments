/*
11. Java program for assignment question 11.
*/
class Book {
    String title, author;
    float price;

    void setDetails(String t, String a, float p) {
        title = t;
        author = a;
        price = p;
    }

    void display() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Price: " + price);
    }
}

public class Program11_Books {
    public static void main(String[] args) {
        Book[] books = new Book[3];
        for (int i = 0; i < 3; i++) {
            books[i] = new Book();
            books[i].setDetails("Book" + (i + 1), "Author" + (i + 1), (i + 1) * 100);
            books[i].display();
        }
    }
}