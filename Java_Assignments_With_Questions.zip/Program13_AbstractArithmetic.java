/*
13. Java program for assignment question 13.
*/
abstract class Arithmetic {
    abstract void calculate(int a, int b);
}

class Operations extends Arithmetic {
    void calculate(int a, int b) {
        System.out.println("Add: " + (a + b));
        System.out.println("Subtract: " + (a - b));
        System.out.println("Multiply: " + (a * b));
    }
}

public class Program13_AbstractArithmetic {
    public static void main(String[] args) {
        Operations op = new Operations();
        op.calculate(6, 3);
    }
}