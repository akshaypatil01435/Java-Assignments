/*
9. Java program for assignment question 9.
*/
class A {
    int a = 10, b = 20;
}

class B extends A {
    int c = 30;

    void sum() {
        System.out.println("Sum: " + (a + b + c));
    }
}

public class Program9_SingleInheritance {
    public static void main(String[] args) {
        B obj = new B();
        obj.sum();
    }
}