/*
4. Java program for assignment question 4.
*/
class Account {
    int accNo;
    String name;
    float balance;

    void acceptData(int a, String n, float b) {
        accNo = a;
        name = n;
        balance = b;
        displayData();
    }

    void displayData() {
        System.out.println("Account No: " + accNo);
        System.out.println("Name: " + name);
        System.out.println("Balance: " + balance);
    }
}

public class Program4_Account {
    public static void main(String[] args) {
        Account acc = new Account();
        acc.acceptData(12345, "John", 2500.75f);
    }
}