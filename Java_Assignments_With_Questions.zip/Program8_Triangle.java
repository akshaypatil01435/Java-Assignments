/*
8. Java program for assignment question 8.
*/
class Triangle {
    Triangle(float base, float height) {
        float area = 0.5f * base * height;
        System.out.println("Area of Triangle: " + area);
    }
}

public class Program8_Triangle {
    public static void main(String[] args) {
        Triangle t = new Triangle(5, 10);
    }
}